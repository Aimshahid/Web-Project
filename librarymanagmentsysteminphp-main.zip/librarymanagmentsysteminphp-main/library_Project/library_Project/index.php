<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title>Login Form</title>
        <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
      <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
      <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
        <link rel="stylesheet" href="style.css">
    </head>
    <style>

    body{
        background-image: url('images/main.jpg')
    }

    .login-form-3 .btnSubmit {
        padding:8px;
        font-size: 18px;
    font-weight: 800;
    color: #522929;
    background-color: #FFFFFF;
}

.login-form-1 .btnSubmit {
    padding:8px;
    font-size: 18px;
    font-weight: 800;
    color: #522929;
    background-color: #FFFFFF;
}

.login-form-3 h1 {
    text-align: center;
    color: white;
    -webkit-text-stroke: 1px #5E644C;
    
}

.login-form-1 h1 {
    text-align: center;
    color: white;
    -webkit-text-stroke: 1px #5E644C;
}
.login-form-3 {
    border-radius: 25px;
    left:-50px;
    padding: 5px;
    box-shadow: 5px 5px 8px 5px #AD9D9D ;
    background-color:#341B09;
    opacity:0.8;
}
.login-form-1 { 
    border-radius: 25px;
    right: -250px;
    padding: 5px;
    box-shadow: 5px 5px 8px 5px #AD9D9D;
    background-color:#341B09;
    opacity:0.8;
}
input[type="text"]
{
    font-size:20px;
}
input[type="password"]{
    font-size:20px;
}

    </style>
    <body >

<?php
 $emailmsg="";
 $pasdmsg="";
 $msg="";

 $ademailmsg="";
 $adpasdmsg="";


 if(!empty($_REQUEST['ademailmsg'])){
    $ademailmsg=$_REQUEST['ademailmsg'];
 }

 if(!empty($_REQUEST['adpasdmsg'])){
    $adpasdmsg=$_REQUEST['adpasdmsg'];
 }

 if(!empty($_REQUEST['emailmsg'])){
    $emailmsg=$_REQUEST['emailmsg'];
 }

 if(!empty($_REQUEST['pasdmsg'])){
  $pasdmsg=$_REQUEST['pasdmsg'];
}

if(!empty($_REQUEST['msg'])){
    $msg=$_REQUEST['msg'];
 }

 ?>


<header style="Font-family:Source Sans Pro, Arial, sans-serif;font-weight:bold;max-width:100%;padding:8px;color:#FFFFFF; text-align:center; background-color:#432007;"><h1> A & M LIBRARY</h1></header>
<div class="container login-container">
<div class="row"><h4><?php echo $msg?></h4></div>
            <div class="row">
 
                <div class="col-md-5 login-form-3">
                    <h1 style="font-family: Source Sans Pro, Arial, sans-serif">Admin Login</h2>
                    <form action="loginadmin_server_page.php" method="get">
                        <div class="form-group">
                            <input type="text" class="form-control" name="login_email" placeholder="Your Email *" value="" />
                        </div>
                        <Label style="color:red">*<?php echo $ademailmsg?></label>
                        <div class="form-group">
                            <input type="password" class="form-control" name="login_pasword"  placeholder="Your Password *" value="" />
                        </div>
                        <Label style="color:red">*<?php echo $adpasdmsg?></label>
                        <div class="form-group">
                            <input type="submit" class="btnSubmit" value="Login" />
                        </div>
                        <!-- <div class="form-group">

                            <a href="#" class="ForgetPwd" value="Login">Forget Password?</a>
                        </div> -->
                    </form>
                </div>
                <div class="col-md-5 login-form-1">
                    <h1 style="font-family:Source Sans Pro, Arial, sans-serif;">Student Login</h2>
                    <form action="login_server_page.php" method="get">
                        <div class="form-group">
                            <input type="text" class="form-control" name="login_email" placeholder="Your Email *" value="" />
                        </div>
                        <Label style="color:red">*<?php echo $emailmsg?></label>
                        <div class="form-group">
                            <input type="password" class="form-control" name="login_pasword"  placeholder="Your Password *" value="" />
                        </div>
                        <Label style="color:red">*<?php echo $pasdmsg?></label>
                        <div class="form-group">
                            <input type="submit" class="btnSubmit" value="Login" />
                        </div>
                    </form>
                </div>
            </div>
        </div>



        



        <script src="" async defer></script>
    </body>
</html>